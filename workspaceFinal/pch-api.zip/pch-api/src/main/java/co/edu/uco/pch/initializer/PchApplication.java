package co.edu.uco.pch.initializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PchApplication {

	public static void main(String[] args) {
		SpringApplication.run(PchApplication.class, args);
	}

}
